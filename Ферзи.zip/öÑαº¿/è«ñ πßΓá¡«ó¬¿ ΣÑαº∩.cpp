﻿#include <iostream>
using namespace std;
int board[8][8];
void initializeBoard() // Инициализация доски
{
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            board[i][j] = 0;
        }
    }
}
void show()
{
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if (board[i][j] == 1) {
                cout << "\033[33m" << board[i][j] << " " << "\033[0m"; // Подкрашиваем 1 желтым цветом
            }
            else if (board[i][j] == -1) {
                cout << "\033[31m" << board[i][j] << " " << "\033[0m"; // Подкрашиваем -1 красным цветом
            }
            else {
                cout << board[i][j] << " ";
            }
        }
        cout << endl;
    }
}
void placeQueen(int i, int j) // Установка ферзя
{
    for (int x = 0; x < 8; ++x) {
        board[x][j] += 1;
        board[i][x] += 1;

        int d;
        d = j - i + x;
        if (d >= 0 && d < 8) {
            board[x][d] += 1;
        }

        d = j + i - x;
        if (d >= 0 && d < 8) {
            board[x][d] += 1;
        }
        cout << "\033[31m" << "x = " << x << ":" << " " << "\033[0m" << endl;
        show();
    }
    board[i][j] = -1;
    cout << "Result: " << endl;
    show();
}

int main()
{
    initializeBoard();
    placeQueen(3, 5);
}