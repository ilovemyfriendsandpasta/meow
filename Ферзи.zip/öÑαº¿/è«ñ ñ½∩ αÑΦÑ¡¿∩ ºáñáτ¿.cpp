﻿#include <iostream>
using namespace std;

int board[8][8];

void initializeBoard()
{
    // Инициализация доски
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            board[i][j] = 0;
        }
    }
}

void displayBoard()
{
    // Отображение доски с символами
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (board[i][j] == -1) {
                cout << "Q "; // Ферзь
            }
            else {
                cout << ". "; // Пустая клетка
            }
        }
        cout << endl;
    }
}

void placeQueen(int i, int j)
{
    // Размещение ферзя и отметка атакованных клеток
    for (int x = 0; x < 8; ++x) {
        board[x][j] += 1;
        board[i][x] += 1;

        int d;
        d = j - i + x;
        if (d >= 0 && d < 8) {
            board[x][d] += 1;
        }

        d = j + i - x;
        if (d >= 0 && d < 8) {
            board[x][d] += 1;
        }
    }
    board[i][j] = -1; // Устанавливаем ферзя
}

void removeQueen(int i, int j)
{
    // Удаление ферзя и обновление отметок
    for (int x = 0; x < 8; ++x) {
        board[x][j] -= 1;
        board[i][x] -= 1;

        int d;
        d = j - i + x;
        if (d >= 0 && d < 8) {
            board[x][d] -= 1;
        }

        d = j + i - x;
        if (d >= 0 && d < 8) {
            board[x][d] -= 1;
        }
    }
    board[i][j] = 0; // Удаляем ферзя
}

bool checkQueen(int i)
{
    bool result = false;

    for (int j = 0; j < 8; ++j) { // Итерация по столбцам
        if (board[i][j] == 0) { // Если клетка свободна от ферзя
            placeQueen(i, j); // Размещаем ферзя и отмечаем атакованные клетки

            if (i == 7) { // Если последняя строка, все ферзи расставлены
                result = true;
            }
            else if (!(result = checkQueen(i + 1))) { // Если неудачно, удалить ферзя и продолжить проверку
                removeQueen(i, j);
            }
        }
        if (result) break;
    }
    return result;
}

int main()
{
    initializeBoard();
    checkQueen(0);
    displayBoard();
    return 0;
}
